
DROP INDEX idx_content_key;
DROP TABLE site_content;
