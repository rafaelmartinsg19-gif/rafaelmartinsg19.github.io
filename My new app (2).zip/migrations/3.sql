
-- Add new content types for media and styling
INSERT INTO site_content (content_key, content_type, content_value) VALUES
('hero_background_image', 'image', 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?q=80&w=2070&auto=format&fit=crop'),
('site_logo', 'image', ''),
('gallery_image_1', 'image', 'https://images.unsplash.com/photo-1619405399517-d7fce0f13302?q=80&w=2070&auto=format&fit=crop'),
('gallery_image_2', 'image', 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?q=80&w=2064&auto=format&fit=crop'),
('gallery_image_3', 'image', 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?q=80&w=2068&auto=format&fit=crop'),
('gallery_image_4', 'image', 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=1966&auto=format&fit=crop'),
('promo_video_url', 'text', ''),
('promo_video_thumbnail', 'image', ''),
('hero_title_font', 'text', 'Inter'),
('hero_title_size', 'text', '48'),
('hero_subtitle_font', 'text', 'Inter'),
('hero_subtitle_size', 'text', '24');
