
DELETE FROM site_content WHERE content_key IN (
  'hero_background_image',
  'site_logo',
  'gallery_image_1',
  'gallery_image_2',
  'gallery_image_3',
  'gallery_image_4',
  'promo_video_url',
  'promo_video_thumbnail',
  'hero_title_font',
  'hero_title_size',
  'hero_subtitle_font',
  'hero_subtitle_size'
);
